from setuptools import setup, find_packages

setup(
    name='geomesa_pyspark',
    version='3.1.0',
    url='http://www.geomesa.org',
    packages=find_packages(),
    install_requires=['pytz', 'shapely']
)
